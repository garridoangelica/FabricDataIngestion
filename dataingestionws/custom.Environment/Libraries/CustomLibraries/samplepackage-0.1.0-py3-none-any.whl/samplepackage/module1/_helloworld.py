def print_hello(name):
    print(f'Hello {name}')
    return